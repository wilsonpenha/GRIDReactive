# bash/sh

java -cp .:./lib/commons-codec-1.4.jar:./lib/commons-httpclient-3.1.jar:./lib/commons-io-2.4.jar:./lib/commons-lang-2.6.jar:./lib/commons-logging-1.1.1.jar:./lib/java-json.jar br.com.gridreactive.RetrieveGitHubWithTweets