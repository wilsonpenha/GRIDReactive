package br.com.gridreactive.exception;

/**
 * Base P2W Exception Class. This exception has been to have all the other P2W
 * Exceptions derivating from it.
 * 
 * @author jorgeas
 *
 */
public class SearchTweetsException extends Exception {
	/**
	 * Serial Version UID
	 */
	private static final long serialVersionUID = -104831425731568578L;
	private String code;
	public static final String HTTP_403 = "403";

	/**
	 * Constructs a new P2W exception with <code>null</code> as its detail
	 * message.
	 */
	public SearchTweetsException() {
		super();
	}
	
	/**
	 * Constructs a new P2W exception with the specified detail message.
	 * 
	 * @param message
	 *            the detail message. The detail message is saved for later
	 *            retrieval by the {@link #getMessage()} method.
	 */
	public SearchTweetsException(String message, String code) {
		super(message);
		this.code = code;
	}
	
	/**
	 * Constructs a new SearchTweetsException with the specified detail message and
	 * cause.
	 * <p>
	 * Note that the detail message associated with <code>cause</code> is
	 * <i>not</i> automatically incorporated in this exception's detail
	 * message.
	 * 
	 * @param message
	 *            the detail message (which is saved for later retrieval by the
	 *            {@link #getMessage()} method).
	 * @param cause
	 *            the cause (which is saved for later retrieval by the
	 *            {@link #getCause()} method). (A <tt>null</tt> value is
	 *            permitted, and indicates that the cause is nonexistent or
	 *            unknown.)
	 */
	public SearchTweetsException(String message, Throwable cause, String code) {
		super(message, cause);
		this.code = code;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
}
